var navbar = document.getElementById("navbar");
var menu = document.getElementById("menu");

window.onscroll = function(){
    if(window.pageYOffset >= menu.offsetTop){
        navbar.classList.add("sticky");
    }
    else{
        menu.classlist.remove("sticky");
    }
}

function scroll1(){
    document.getElementById("content1").scrollIntoView();
}

function scroll2(){
    document.getElementById("content2").scrollIntoView();
}

function scroll3(){
    document.getElementById("content3").scrollIntoView();
}

function scroll4(){
    document.getElementById("content4").scrollIntoView();
}

function scroll5(){
    document.getElementById("content5").scrollIntoView();
}

function scroll6(){
    document.getElementById("content6").scrollIntoView();
}

function scroll7(){
    document.getElementById("content7").scrollIntoView();
}

function scroll8(){
    document.getElementById("content8").scrollIntoView();
}


