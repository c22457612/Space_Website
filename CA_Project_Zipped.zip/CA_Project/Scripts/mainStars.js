var navbar = document.getElementById("navbar");
var menu = document.getElementById("menu");

window.onscroll = function(){
    if(window.pageYOffset >= menu.offsetTop){
        navbar.classList.add("sticky");
    }
    else{
        menu.classlist.remove("sticky");
    }
}

function changeText1() {
  document.querySelector(".displayHeading").textContent ="Prostars"
  document.querySelector(".displayText1").textContent = "A protostar is what you have before a star forms. A protostar is a collection of gas that has collapsed down from a giant molecular cloud.";
  document.querySelector(".displayImg").src="Images/prostar.jpg";
  document.querySelector(".displayText2").textContent = "All of the energy released by the protostar comes only from the heating caused by the gravitational energy.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText2() {
  document.querySelector(".displayHeading").textContent ="T-Tauri Stars"
  document.querySelector(".displayText1").textContent = "A T Tauri star is a stage in a star’s formation and evolution right before it becomes a main-sequence star.This phase occurs at the end of the protostar phase when the gravitational pressure holding the star together is the source of all its energy.";
  document.querySelector(".displayImg").src="Images/t-tauri-star.png";
  document.querySelector(".displayText2").textContent = "T tauri stars resemble main sequence stars. They’re about the same temperature as main sequence stars but brighter because they’re larger. Stars will remain in the T Tauri stage for about 100 million years.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText3() {
  document.querySelector(".displayHeading").textContent ="Blue Stars"
  document.querySelector(".displayText1").textContent = "Blue Stars are often hot and found in complex multi-star systems. Mass transfer between stars makes predicting the evolution of these stars difficult.These stars burn hotter than our sun but for much less time.";
  document.querySelector(".displayImg").src="Images/blueStars.jpg";
  document.querySelector(".displayText2").textContent = "Because blue stars are so hot and massive, they have relatively short lives that end in violent supernova events, ultimately resulting in the creation of either black holes or neutron stars.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText4() {
  document.querySelector(".displayHeading").textContent ="Red Dwarf Stars"
  document.querySelector(".displayText1").textContent = "Red Dwarf Stars are the most common kind of stars in the universe, however they have such low mass they are much cooler than stars like our Sun.They have to potential to live for hundreds of billions of years. Red dwarf stars are able to keep the hydrogen fuel mixing into their core, and so they can conserve their fuel for much longer than other stars.";
  document.querySelector(".displayImg").src="Images/redDwarf.png";
  document.querySelector(".displayText2").textContent = "Red Dwarf stars are actually quite dim and hard to see, however one of the nearest Red Dwarf's, Barnard's star should be visible with the use of a small telescope.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText5() {
  document.querySelector(".displayHeading").textContent ="Yellow Dwarf Stars"
  document.querySelector(".displayText1").textContent = "A yellow dwarf is a star belonging to the main sequence of spectral type G stars.About 10% of stars in the Milky Way are dwarf yellow. They have a surface temperature of about 6000 ° C and shine a bright yellow, almost white.Typical G-type stars have between 0.84 and 1.15 solar masses, and temperatures that fall into a narrow range of between 5,300K and 6,000K.";
  document.querySelector(".displayImg").src="Images/yellowDwarf.png";
  document.querySelector(".displayText2").textContent = "Our Sun is an example of a G-type star, but it is, in fact inaccurately referred to as a yellow dwarf as its light it emits is actually white.Like the Sun, all G-type stars convert hydrogen into helium in their cores, and will evolve into red giants as their supply of hydrogen fuel is depleted.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText6() {
  document.querySelector(".displayHeading").textContent ="Orange Dwarf Stars"
  document.querySelector(".displayText1").textContent = "Orange Dwarf Stars are K-type stars.K-type stars are of particular interest in the search for extraterrestrial life, since they emit markedly less UV radiation (that damages or destroys DNA) than G-type stars.Moreover, K-type stars are about four times as common as G-type stars, making the search for exoplanets a lot easier.";
  document.querySelector(".displayImg").src="Images/orangeDwarf.jpg";
  document.querySelector(".displayText2").textContent = "Orange Dwarf Stars remain stable for up to about 30 billion years, as compared to about 10 billion years for the Sun.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText7() {
  document.querySelector(".displayHeading").textContent ="Blue Giant Stars"
  document.querySelector(".displayText1").textContent = "Stars with luminosity classifications of III and II (bright giant and giant) are referred to as blue giant stars.The term applies to a variety of stars in different phases of development. They are evolved stars but have little else in common.Blue giants are much rarer than red giants, because they only develop from more massive and less common stars, and because they have short lives. Some stars are mislabelled as blue giants because they are big and hot.";
  document.querySelector(".displayImg").src="Images/blueGiant.jpg";
  document.querySelector(".displayText2").textContent = "Blue Supergiants are a class of star that also exist. They are typically larger han the Sun, but smaller than red supergiant stars, and fall into a mass range of between 10 and 100 solar masses. Typically Blue Supergiants last only a few million years since they burn through their supply of hydrogen very quickly due to their high masses.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText8() {
  document.querySelector(".displayHeading").textContent ="Red Giant Stars"
  document.querySelector(".displayText1").textContent = "When a star has consumed its stock of hydrogen in its core, fusion stops and the star no longer generates an outward pressure to counteract the inward pressure pulling it together.The aging star has become a red giant star.The red giant phase of a star’s life will only last a few hundred million years before it runs out of fuel completely and becomes a white dwarf.";
  document.querySelector(".displayImg").src="Images/redGiant.png";
  document.querySelector(".displayText2").textContent = "Red supergiant stars are a class of stars that also exit.They form when Red Giants have exhausted their supply of hydrogen at their cores, and as a result, their outer layers expand hugely as they evolve.Stars of this type are among the biggest stars known in terms of sheer bulk, although they are generally not among the most massive or luminous.";
  document.getElementById("displayView").scrollIntoView();
}


function changeText9() {
  document.querySelector(".displayHeading").textContent ="White Dwarf Stars"
  document.querySelector(".displayText1").textContent = "When a star has completely run out of hydrogen fuel in its core and it lacks the mass to force higher elements into fusion reaction, it becomes a white dwarf star.The outward light pressure from the fusion reaction stops and the star collapses inward under its own gravity.";
  document.querySelector(".displayImg").src="Images/whiteDwarf.jpg";
  document.querySelector(".displayText2").textContent = "A white dwarf shines because it was a hot star once, but there’s no fusion reactions happening anymore. A white dwarf will just cool down until it becomes the background temperature of the Universe. This process will take hundreds of billions of years, so no white dwarfs have actually cooled down that far yet.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText10() {
  document.querySelector(".displayHeading").textContent ="Neutron Stars"
  document.querySelector(".displayText1").textContent = "Neutron stars are the collapsed cores of massive stars (between 10 and 29 solar masses) that were compressed past the white dwarf stage during a supernova explosion.The remaining core becomes a neutron star. A neutron star is an unusual type of star that is composed entirely of neutrons; particles that are marginally more massive than protons, but carry no electrical charge.";
  document.querySelector(".displayImg").src="Images/neutronStar.jpg";
  document.querySelector(".displayText2").textContent = "The intense gravity of the neutron star crushes protons and electrons together to form neutrons. If stars are even more massive, they will become black holes instead of neutron stars after the supernova goes off.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText11() {
  document.querySelector(".displayHeading").textContent ="Brown Dwarf Stars"
  document.querySelector(".displayText1").textContent = "Brown Dwarfs are also known as failed stars. This is due to the result of their formation. Brown Dwarfs form just like regular stars normally would. However, unlike regular stars, brown dwarfs do not have sufficient mass to ignite and fuse hydrogen in their cores. They, therefore, don’t shine and can be small.";
  document.querySelector(".displayImg").src="Images/brownDwarf.png.";
  document.querySelector(".displayText2").textContent = "Typically, Brown Dwarf Stars size fall into the mass range of 13 to 80 Jupiter-masses, with sub-brown dwarf stars falling below this range.";
  document.getElementById("displayView").scrollIntoView();
}

function changeText12() {
  document.querySelector(".displayHeading").textContent ="Binary Stars"
  document.querySelector(".displayText1").textContent = "A binary star is a system of two stars that rotate around a common center of mass. About half of all stars are in a group of at least two stars. Another classification of Binary Star is an eclipsing binary, these are two close stars that appear to be a single star varying in brightness. The variation in brightness is due to the stars periodically obscuring or enhancing one another. ";
  document.querySelector(".displayImg").src="Images/binaryStars.jpg";
  document.querySelector(".displayText2").textContent = "X-ray binary stars are a special type of binary star in which one of the stars is a collapsed object such as a white dwarf, neutron star, or black hole. As matter is stripped from the normal star, it falls into the collapsed star, producing X-rays.";
  document.getElementById("displayView").scrollIntoView();
}