var navbar = document.getElementById("navbar");
var menu = document.getElementById("menu");

window.onscroll = function(){
    if(window.pageYOffset >= menu.offsetTop){
        navbar.classList.add("sticky");
    }
    else{
        menu.classlist.remove("sticky");
    }
}

function scroll1(){
  document.getElementById("content1").scrollIntoView();
}

function scroll2(){
  document.getElementById("content2").scrollIntoView();
}

function scroll3(){
  document.getElementById("content3").scrollIntoView();
}

function scroll4(){
  document.getElementById("content4").scrollIntoView();
}

function scroll5(){
  document.getElementById("content5").scrollIntoView();
}

function scroll6(){
  document.getElementById("content6").scrollIntoView();
}

function scroll7(){
  document.getElementById("content7").scrollIntoView();
}

function scroll8(){
  document.getElementById("content8").scrollIntoView();
}



function changeMars1() {
  document.querySelector(".marsMoons").textContent = "Deimos is the smaller and outermost of the two natural satellites of Mars, the other being Phobos.Deimos has a mean radius of 6.2 km (3.9 mi) and takes 30.3 hours to orbit Mars. Deimos is 23,460 km (14,580 mi) from Mars, much farther than Mars's other moon, Phobos. It is named after Deimos, the Ancient Greek god and personification of dread and terror. Like most bodies of its size, Deimos is highly non-spherical with triaxial dimensions of 15 x 12.2 x 11 km, making it 56% of the size of Phobos. Deimos is composed of rock rich in carbonaceous material. It is cratered, but the surface is noticeably smoother than that of Phobos, caused by the partial filling of craters with regolith.Escape velocity from Deimos is 5.6 m/s. This velocity could theoretically be achieved by a human performing a vertical jump.The apparent magnitude of Deimos is 12.45.Only two geological features on Deimos have been given names. The craters Swift and Voltaire are named after writers who speculated on the existence of two Martian moons before Phobos and Deimos were discovered.";
  document.querySelector(".marsmoonImg").src="Images/deimos.jpg";
}

function changeMars2() {
  document.querySelector(".marsMoons").textContent = "Phobos is the innermost and larger of the two natural satellites of Mars, the other being Deimos. The two moons were discovered in 1877 by American astronomer Asaph Hall. Phobos is named after the Greek deity Phobos, a son of Ares (Mars) and twin brother of Deimos.Phobos is a small, irregularly shaped object with an average radius of 11 km (7 mi) Phobos orbits 6,000 km (3,700 mi) from the Martian surface, closer to its primary body than any other known planetary moon. It is so close that it orbits Mars much faster than Mars rotates, and completes an orbit in just 7 hours and 39 minutes. As a result, from the surface of Mars it appears to rise in the west, move across the sky in 4 hours and 15 minutes or less, and set in the east, twice each Martian day.However, Phobos is one of the least reflective bodies in the Solar System. Surface temperatures range from about -4 °C (25 °F) on the sunlit side to -112 °C (-170 °F) on the shadowed side. The defining surface feature is the large impact crater, Stickney, which takes up a substantial proportion of the moon's surface.Images and models indicate that Phobos may be a rubble pile held together by a thin crust that is being torn apart by tidal interactions. Phobos gets closer to Mars by about 2 cm per year, and it is predicted that within 30 to 50 million years it will either collide with the planet or break up into a planetary ring.";
  document.querySelector(".marsmoonImg").src="Images/phobos.jpg";
}

function changeJupiter1() {
  document.querySelector(".jupiterMoons").textContent = "Io or Jupiter I, is the innermost and third-largest of the four Galilean moons of the planet Jupiter. Slightly larger than Earth's moon, Io is the fourth-largest moon in the Solar System, has the highest density of any moon, the strongest surface gravity of any moon, and the lowest amount of water of any known astronomical object in the Solar System. It was discovered in 1610 by Galileo Galilei and was named after the mythological character Io. With over 400 active volcanoes, Io is the most geologically active object in the Solar System. This extreme geologic activity is the result of tidal heating from friction generated within Io's interior as it is pulled between Jupiter and the other Galilean moons—Europa, Ganymede and Callisto. Several volcanoes produce plumes of sulfur and sulfur dioxide that climb as high as 500 km (300 mi) above the surface. Io's surface is also dotted with more than 100 mountains that have been uplifted  at the base of Io's silicate crust. Some of these peaks are taller than Mount Everest, the highest point on Earth's surface. Io is primarily composed of silicate rock surrounding a molten iron or iron sulfide core."; 
  document.querySelector(".jupiterMoonImg").src="Images/lo.jpg";
}

function changeJupiter2() {
  document.querySelector(".jupiterMoons").textContent = "Europa or Jupiter II, is the smallest of the four Galilean moons orbiting Jupiter, and the sixth-closest to the planet of all the 80 known moons of Jupiter. It is also the sixth-largest moon in the Solar System. Europa was discovered in 1610 by Galileo Galilei and was named after Europa. Slightly smaller than Earth's Moon, Europa is primarily made of silicate rock and has a water-ice crust and most likely an iron-nickel core. It has a very thin atmosphere, composed primarily of oxygen. Its white-beige surface is striated by light tan cracks and streaks, with relatively few craters. In addition to Earth-bound telescope observations, Europa has been examined by a succession of space-probes, the first occurring in the early 1970s. In September 2022, the Juno spacecraft flew within about 200 miles of Europa for a more recent close-up view.Europa has the smoothest surface of any known solid object in the Solar System. The apparent youth and smoothness of the surface have led to the hypothesis that a water ocean exists beneath the surface, which could conceivably harbor extraterrestrial life.";
  document.querySelector(".jupiterMoonImg").src="Images/europa.png";
}

function changeJupiter3() {
  document.querySelector(".jupiterMoons").textContent = "Ganymede or Jupiter III, is the largest and most massive of the Solar System's moons. The ninth-largest object (including the Sun) of the Solar System, it is the largest without a substantial atmosphere (although not the most massive one, this is Mercury). It has a diameter of 5,268 km (3,273 mi), making it 26 percent larger than the planet Mercury by volume, although it is only 45 percent as massive. Possessing a metallic core, it is the only moon known to have a magnetic field. Outward from Jupiter, it is the seventh satellite and the third of the Galilean moons, the first group of objects discovered orbiting another planet. Ganymede orbits Jupiter in roughly seven days and is in orbital resonance with the moons Europa and Io. Ganymede is composed of approximately equal amounts of silicate rock and water. It is a fully differentiated body with an iron-rich, liquid core, and an internal ocean that may contain more water than all of Earth's oceans combined. Its surface is composed of two main types of terrain. Dark regions, saturated with impact craters and dated to four billion years ago, cover about a third of it. Lighter regions, crosscut by extensive grooves and ridges and only slightly less ancient, cover the remainder. The cause of the light terrain's disrupted geology is not fully known, but was likely the result of tectonic activity due to tidal heating. Ganymede has a meager magnetic field and is buried within Jupiter's far larger magnetic field. Ganymede has a thin oxygen atmosphere that includes O, O2, and possibly O3 (ozone).";
  document.querySelector(".jupiterMoonImg").src="Images/ganymede.png";
}

function changeJupiter4() {
  document.querySelector(".jupiterMoons").textContent = "Callisto, or Jupiter IV, is the second-largest moon of Jupiter, after Ganymede. It is the third-largest moon in the Solar System after Ganymede and Saturn's largest moon Titan, and the largest object in the Solar System that may not be properly differentiated. Callisto was discovered in 1610 by Galileo Galilei. With a diameter of 4821 km, Callisto is about 99% the diameter of the planet Mercury, but only about a third of its mass. It is the fourth Galilean moon of Jupiter by distance, with an orbital radius of about 1883000 km. It is not in an orbital resonance like the three other Galilean satellites—Io, Europa, and Ganymede—and is therefore not tidally heated. Callisto's rotation is tidally locked to its orbit around Jupiter, so that the same hemisphere always faces inward. Because of this, there is a sub-Jovian point on Callisto's surface, from which Jupiter would appear to hang directly overhead. It is less affected by Jupiter's magnetosphere than the other inner satellites because of its more remote orbit, located just outside Jupiter's main radiation belt. Callisto is composed of rock and ice, with a density of about 1.83 g/cm3, the lowest density and surface gravity of Jupiter's major moons. Compounds detected on the surface include water ice, carbon dioxide, silicates, and organic compounds.The surface of Callisto is the oldest and most heavily cratered in the Solar System. Its surface is completely covered with impact craters.";
  document.querySelector(".jupiterMoonImg").src="Images/callisto.jpg";
}

function changeSaturn1() {
  document.querySelector(".saturnMoons").textContent = "Enceladus is the sixth-largest moon of Saturn (19th largest in the Solar System). It is about 500 kilometers (310 miles) in diameter, about a tenth of that of Saturn's largest moon, Titan. Enceladus is mostly covered by fresh, clean ice, making it one of the most reflective bodies of the Solar System. Consequently, its surface temperature at noon only reaches -198 °C (-324.4 °F). Enceladus has a wide range of surface features, despite being small, ranging from old, heavily cratered regions to young, tectonically deformed terrains. Enceladus was discovered on August 28, 1789, by William Herschel. Little was known about it until Voyager 1 and Voyager 2, flew by Saturn in 1980 and 1981. In 2005, it was discovered water-rich plumes venting from the south polar region. Cryovolcanoes near the south pole shoot geyser-like jets of water vapor, molecular hydrogen, other volatiles, and solid material, including sodium chloride crystals and ice particles, into space, totaling about 200 kilograms (440 pounds) per second. More than 100 geysers have been identified. Some of the water vapor falls back as 'snow'; the rest escapes and supplies most of the material making up Saturn's ring.";
  document.querySelector(".saturnMoonImg").src="Images/enceladus.jpeg";
}

function changeSaturn2() {
  document.querySelector(".saturnMoons").textContent = "Titan is the largest moon of Saturn and the second-largest natural satellite in the Solar System. It is the only moon known to have a dense atmosphere, and is the only known object in space other than Earth on which clear evidence of stable bodies of surface liquid has been found. Frequently described as a planet-like moon, Titan is 50% larger (in diameter) than Earth's Moon and 80% more massive. It is the second-largest moon in the Solar System after Jupiter's moon Ganymede, and is larger than the planet Mercury, but only 40% as massive. Discovered in 1655 by the Dutch astronomer Christiaan Huygens, Titan was the first known moon of Saturn. From Titan's surface, if Saturn were visible through the moon's thick atmosphere, it would appear 11.4 times larger in the sky, in diameter, than the Moon from Earth, which subtends 0.48° of arc.Titan is primarily composed of ice and rocky material, which is likely differentiated into a rocky core surrounded by various layers of ice, including a crust of ice Ih and a subsurface layer of ammonia-rich liquid water.";
  document.querySelector(".saturnMoonImg").src="Images/titan.jpeg";
}

function changeUranus1() {
  document.querySelector(".uranusMoons").textContent = "Miranda, the innermost and smallest of the five major satellites, has a surface unlike any other moon that's been seen. It has giant fault canyons as much as 12 times as deep as the Grand Canyon, terraced layers and surfaces that appear very old, and others that look much younger.";
  document.querySelector(".uranusMoonImg").src="Images/miranda.jpg";
}


function changeUranus2() {
  document.querySelector(".uranusMoons").textContent = "Ariel has the brightest and possibly the youngest surface among all the moons of Uranus. It has few large craters and many small ones, indicating that fairly recent low-impact collisions wiped out the large craters that would have been left by much earlier, bigger strikes. Intersecting valleys pitted with craters scar its surface.";
  document.querySelector(".uranusMoonImg").src="Images/ariel.png";
}

function changeUranus3() {
  document.querySelector(".uranusMoons").textContent = "Umbriel is ancient, and the darkest of the five large moons. It has many old, large craters and sports a mysterious bright ring on one side.";
  document.querySelector(".uranusMoonImg").src="Images/umbriel.webp";
}

function changeUranus4() {
  document.querySelector(".uranusMoons").textContent = "Oberon, the outermost of the five major moons, is old, heavily cratered, and shows little signs of internal activity. Unidentified dark material appears on the floors of many of its craters.";
  document.querySelector(".uranusMoonImg").src="Images/oberon.jpg";
}

function changeUranus5() {
  document.querySelector(".uranusMoons").textContent = "Titania is Uranus' largest moon. Images taken by Voyager 2 almost 200 years after Titania's discovery revealed signs that the moon was geologically active.A prominent system of fault valleys, some nearly 1,000 miles (1,609 kilometers) long, is visible near the terminator (shadow line). The troughs break the crust in two directions, an indication of some tectonic extension of Titania's crust. Deposits of highly reflective material, which may represent frost, can be seen along the Sun-facing valley walls.The moon is about 1,000 miles (1,600 kilometers) in diameter. The neutral gray color of Titania is typical of most of the significant Uranian moons.";
  document.querySelector(".uranusMoonImg").src="Images/titania.jpg";
}

function changeNeptune1() {
  document.querySelector(".neptuneMoons").textContent = "Triton is the largest natural satellite of the planet Neptune, and was the first Neptunian moon to be discovered, on October 10, 1846, by English astronomer William Lassell. It is the only large moon in the Solar System with a retrograde orbit, an orbit in the direction opposite to its planet's rotation. As a result of its retrograde orbit and composition similar to Pluto, Triton is thought to have been a dwarf planet, captured from the Kuiper belt. At 2,710 kilometers (1,680 mi) in diameter, it is the seventh-largest moon in the Solar System, the second-largest planetary moon in relation to its primary (after Earth's Moon), and larger than Pluto. Triton is one of the few moons in the Solar System known to be geologically active (the others being Jupiter's Io and Europa, and Saturn's Enceladus and Titan). As a consequence, its surface is relatively young, with few obvious impact craters. Triton has a surface of mostly frozen nitrogen, a mostly water-ice crust, an icy mantle and a substantial core of rock and metal. The core makes up two thirds of its total mass.In 1989, surface temperatures of -235 °C were discovered along with active geysers erupting sublimated nitrogen gas, contributing to a tenuous nitrogen atmosphere less than 1⁄70,000 the pressure of Earth's atmosphere at sea level.";
  document.querySelector(".neptuneMoonImg").src="Images/triton.jpg";
}


function changeNeptune2() {
  document.querySelector(".neptuneMoons").textContent = "Proteus, also known as Neptune VIII, is the second-largest Neptunian moon, and Neptune's largest inner satellite. Discovered by Voyager 2 spacecraft in 1989, it is named after Proteus, the shape-changing sea god of Greek mythology. Proteus orbits Neptune in a nearly equatorial orbit at a distance of about 4.75 times the radius of Neptune's equator. Despite being a predominantly icy body more than 400 km (250 mi) in diameter, Proteus's shape deviates significantly from an ellipsoid. It is shaped more like an irregular polyhedron with several slightly concave facets and relief as high as 20 km (12 mi). Its surface is dark, neutral in color, and heavily cratered. Proteus's largest crater is Pharos, which is more than 230 km (140 mi) in diameter. There are also a number of scarps, grooves, and valleys related to large craters.Proteus is probably not an original body that formed with Neptune. It could have accreted later from the debris formed when the largest Neptunian satellite Triton was captured.";
  document.querySelector(".neptuneMoonImg").src="Images/proteus.jpg";
}

function changeNeptune3() {
  document.querySelector(".neptuneMoons").textContent = "The two outermost Neptunian irregular satellites, Psamathe and Neso, have the largest orbits of any natural satellites discovered in the Solar System to date.Psamathe, also known as Neptune X, is a retrograde irregular satellite of Neptune. It is named after Psamathe, one of the Nereids. Psamathe was discovered by Scott S. Sheppard and David C. Jewitt in 2003 using the 8.2 meter Subaru telescope. Before the announcement of its name on February 3, 2007 (IAUC 8802), it was known by the provisional designation S/2003 N 1.Psamathe is about 38 kilometers in diameter. It orbits Neptune at a distance of between 25.7 and 67.7 million km (for comparison, the Sun-Mercury distance varies between 46 million and 69.8 million km) and requires almost 25 Earth years to make one orbit. The orbit of this satellite is close to the theoretical stable separation from Neptune for a body in a retrograde orbit. Given the similarity of Psamathe's orbital parameters with Neso (S/2002 N 4), it was suggested that both irregular satellites could have a common origin in the break-up of a larger moon. Both are further from their primary than any other known moon in the Solar System. Neso, also known as Neptune XIII, is the outermost known natural satellite of Neptune. It is an irregular moon discovered by Matthew J. Holman, Brett J. Gladman, et al. on August 14, 2002, though it went unnoticed until 2003. Neso orbits Neptune at a distance of more than 48 Gm (million km), making it (as of 2015) the most distant known moon of any planet. At apocenter, the satellite is more than 72 Gm from Neptune. This distance is great enough to exceed Mercury's aphelion, which is approximately 70 Gm from the Sun.Neso is also the moon with the longest orbital period, 26.67 years. The image displayed here is of psamathe.";
  document.querySelector(".neptuneMoonImg").src="Images/psamathe.jpg";
  

}
  